function launchOS() {
  const display = document.getElementById('module-display');
  display.innerHTML = '<strong>System Launched!</strong><br>Select a module to begin.';
}

function loadModule(module) {
  const display = document.getElementById('module-display');
  const modules = {
    'v-caster': '🎥 V-Caster Module Loaded - Manage your live virtual production studio.',
    'streamcore': '🔴 StreamCore Module Activated - Begin streaming live across platforms.',
    'glitch': '🌀 Glitch: Code of Chaos - Visual FX Engine for Front-End Dynamics.',
    'v-screen': '🖥️ V-Screen - Manage overlays, scene layouts, and live screens.',
    'v-stage': '🎬 V-Stage - Virtual Stage Controller with performer modes.',
    'pv-keys': '🎹 PV-Keys - Assign shortcuts and macros for live switching.',
    'musicchain': '🎵 PUABOMusicChain - Secure music media through the blockchain.'
  };
  display.innerHTML = modules[module] || 'Error loading module.';
}